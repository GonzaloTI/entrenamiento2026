# seg_desechos > clasificador
https://universe.roboflow.com/entrenamiento-ctwpi/seg_desechos-pjamv

Provided by a Roboflow user
License: CC BY 4.0

